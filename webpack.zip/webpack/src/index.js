import Ogrenci from './ogrenci';

const hazel = new Ogrenci('hazal');
hazel.adiniSoyle();

console.log('merhaba');